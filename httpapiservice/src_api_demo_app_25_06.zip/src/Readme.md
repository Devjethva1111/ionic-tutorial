//------crop plugins----//
npm install angular-cropperjs --save
npm install cropperjs