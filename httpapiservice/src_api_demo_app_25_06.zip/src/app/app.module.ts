import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { Camera } from '@ionic-native/camera/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

// import { IonicStorageModule } from "@ionic/storage";
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { BackgroundMode } from '@ionic-native/background-mode/ngx';
// import { FCM } from '@ionic-native/fcm/ngx';

import { IonicStorageModule } from "@ionic/storage";


// import { ImageCropperModule } from 'ngx-image-cropper';
//import { FullCalendarModule } from '@fullcalendar/angular'; 
//import { AngularCropperjsModule } from 'angular-cropperjs';

@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule,
     IonicModule.forRoot({ mode: 'ios' }), AppRoutingModule,
     IonicStorageModule.forRoot(), 
    // IonicStorageModule.forRoot(),
      HttpClientModule],
  providers: [
    StatusBar,
    SplashScreen,
    Camera,
    // FCM,
    LocalNotifications,
    BackgroundMode,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
