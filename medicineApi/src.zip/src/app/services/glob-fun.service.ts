import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GlobFunService {

  public clickSub: any;

  constructor() { }

}
