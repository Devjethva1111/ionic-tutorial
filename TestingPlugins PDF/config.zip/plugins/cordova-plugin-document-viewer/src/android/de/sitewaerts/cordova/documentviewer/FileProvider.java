package de.sitewaerts.cordova.documentviewer;

public class FileProvider extends androidx.core.content.FileProvider {
}
