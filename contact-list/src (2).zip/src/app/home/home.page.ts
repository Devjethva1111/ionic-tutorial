/* eslint-disable eqeqeq */
import { FormBuilder } from '@angular/forms';
import { Injectable, OnInit } from '@angular/core';
/* eslint-disable @typescript-eslint/semi */
/* eslint-disable @typescript-eslint/naming-convention */
import { Component } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { AlertController, LoadingController } from '@ionic/angular';
import { NgStyle } from '@angular/common';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit{
  // pencil: any = {name: 'a'};

  // filterTerm: string;
//   descending = false;
// order: number;
// eslint-disable-next-line @typescript-eslint/no-inferrable-types
// column: string = 'name';
items: any;
searching = false;
  index: any;
  editdata: any;
  data: any;
  list: any[] = [
    {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      first_name: 'Dev',
      last_name: 'Jethva',
      Mobile_No: '8849768307',
      Note: 'Computer Engineer',
    },
    {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      first_name: 'Dhaval',
      last_name: 'Mesariya',
      Mobile_No: '1234567890',
      Note: 'Electrical Engineer',
    },
    {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      first_name: 'Abhishek',
      last_name: 'Maheriya',
      Mobile_No: '9087651234',
      Note: 'Computer Engineer',
    },
    {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      first_name: 'Sunil',
      last_name: 'Mali',
      Mobile_No: '7890651234',
      Note: 'Accountant',
    },
    {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      first_name: 'Mayak',
      last_name: 'Patel',
      Mobile_No: '6353423876',
      Note: 'Business man',
    },
  ];

  private loading;

  constructor(
    private alert: AlertController,
    private router: Router,
    private route: ActivatedRoute,
    private loadingCtrl: LoadingController
  ) {
    // this.route.queryParams.subscribe(params => {
    //   // if (params && params.speacial){
    //   //   this.data = JSON.parse(params.speacial);
    //   //   console.log('Data Added', this.data);
    //   // }
    //   if (this.router.getCurrentNavigation().extras.state) {
    //     this.data = this.router.getCurrentNavigation().extras.state.myform1;

    //     this.list.push(this.data);
    //     console.log('data is added', this.list);

    //   }
    // });

    // /edit
    // this.route.queryParams.subscribe(params => {

    //   if(this.router.getCurrentNavigation().extras.state){
    //     this.editdata = this.router.getCurrentNavigation().extras.state.myform2;

    //    this.list[this.index] = this.editdata;
    //     console.log('data is availabelqeq', this.list[this.index]);
    //   }
    // });

    this.route.queryParams.subscribe((params) => {
      if (this.router.getCurrentNavigation().extras.state) {
        // this.editdata = this.router.getCurrentNavigation().extras.state.myform2;
        const add = this.router.getCurrentNavigation().extras.state.addData;
        // this.list.push(add);
        // console.log('data is added', this.list);
        console.log('Add data', add);

        const edit = this.router.getCurrentNavigation().extras.state.editdata;
        // this.list[this.index] = edit;
        console.log('Edit data', edit);

        if (add !=   undefined) {
          this.list.push(add);
        } else {
          console.log('Value added', this.index);
          this.list[this.index] = edit;
        }
      }
    });

    this.initializeItems()
  }

ngOnInit(){
}

  onCreateUser() {}

  // Delete Function
  async delete() {
    console.log('Delete Item');
    const alert = await this.alert.create({
      header: 'Are you sure',
      message: 'Do you want to delete',
      buttons: [
        {
          text: 'Cancel',
          role: 'Cancel',
        },
        {
          text: 'Okay',
          handler: () => {
            this.list.splice(0, 1);
          },
        },
      ],
    });
    await alert.present();
  }

  // Edit Function
  edit(index, item) {
    // console.log('Edit Slide work',);
    const index1 = this.list.indexOf(item);
    this.index = index;
    console.log('index check', index);

    const navigationEdit: NavigationExtras = {
      queryParams: {
        speacial: JSON.stringify(item),
      },
    };
    this.router.navigate(['edit'], navigationEdit);
  }

  add() {
    console.log('Add Slide work');
    const navigationAdd: NavigationExtras = {};
    this.router.navigate(['add'], navigationAdd);
  }

  doRefresh(event) {
    console.log('Begin async operation');

    this.loadingCtrl.create({
      message: 'Loading.....'
    }).then((overlay) => {
      this.loading = overlay;
      this.loading.present();
      console.log('Loader is running');
    });

    setTimeout(() => {

      this.loading.dismiss();
      console.log('Loader is not running');
      console.log('Async operation has ended');
      event.target.complete();
    },3000);
  }

  initializeItems(){
    this.items= this.list;
  }

  toggleSearch(ev: any){
this.initializeItems();

const val =ev.target.value;

if(val && val.trim() != ''){
  // eslint-disable-next-line arrow-body-style
  this.items = this.items.filter((item) => {
    // return (item.first_name.toLowerCase().indexOf(val.toLowerCase()) > -1);
    return item.first_name.toLowerCase().indexOf(val.toLowerCase()) > -1 || item.last_name.toLowerCase().indexOf(val.toLowerCase()) > -1
    || item.Mobile_No.toLowerCase().indexOf(val.toLowerCase()) > -1;
  })
}
  }
  // Detail Function
  detail(member) {
    const index = this.list.indexOf(member);

    const navigationAdd: NavigationExtras = {
      queryParams: {
        speacial: JSON.stringify(member),
      },
    };
    this.router.navigate(['details'], navigationAdd);
  }
}
