/* eslint-disable no-trailing-spaces */
/* eslint-disable @typescript-eslint/semi */
/* eslint-disable @typescript-eslint/naming-convention */
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.page.html',
  styleUrls: ['./add.page.scss'],
})
export class AddPage implements OnInit {
  // addlist = [];
  // user: any = 'world';
  myForm: FormGroup;
  submitted = false;
  // defaultDate = '';
  // eslint-disable-next-line @typescript-eslint/no-inferrable-types
  isenabled: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.myForm = this.formBuilder.group({
      first_name: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.pattern('[a-zA-Z ]*'),
        ],
      ],
      Note: ['', [Validators.required, Validators.pattern('[a-zA-Z ]*')]],
      last_name: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.pattern('[a-zA-Z ]*'),
        ],
      ],
      Mobile_No: [
        '',
        [Validators.required, Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')],
      ],
    });
  }

  // eslint-disable-next-line @typescript-eslint/member-ordering
  get errorCtr() {
    return this.myForm.controls;
  }

  async onSubmit() {
    this.submitted = true;

    if (!this.myForm.valid) {
      console.log('All Fields are  required');
      return false;
    } else {
      // const user = 'hello';
      // console.log('user',user);
      // console.log('USER',this.user);

      // eslint-disable-next-line prefer-const
      let navigationExtras: NavigationExtras = {
        state: {
          addData: this.myForm.value,
        },
      };
      console.log(this.myForm.value);
      this.router.navigate(['home'], navigationExtras);
    }
  }
}

// addDetails() {
//   this.addlist.push({
//     name:uname.value,
//     lastname:lname.value,
//     mobileno:number1.value,
//     note:note.value
//   } );
//   const navigationAdd: NavigationExtras = {
//     queryParams: {
//       speacial: JSON.stringify(this.addlist)
//     }
//   }
//   this.router.navigate(['add'], navigationAdd);
// }
