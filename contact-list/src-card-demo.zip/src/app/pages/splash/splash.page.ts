import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SplashScreen } from '@awesome-cordova-plugins/splash-screen/ngx';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-splash',
  templateUrl: './splash.page.html',
  styleUrls: ['./splash.page.scss'],
})
export class SplashPage{

  constructor(private splashScreen: SplashScreen,  public modelCtrl: ModalController,private router: Router) { }

  ngOnInit() {
}

  ionViewDidEnter() {
    this.splashScreen.hide();
    setTimeout(() => {
      this.router.navigate(['/home']);

    }, 1000);
  }
}
