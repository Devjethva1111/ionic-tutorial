import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { AddtocartService } from 'src/app/services/addtocart.service';


@Component({
  selector: 'app-details',
  templateUrl: './details.page.html',
  styleUrls: ['./details.page.scss'],
})

export class DetailsPage implements OnInit {

  single: any;
  slideOpts = {
    initialSlide: 0,
    speed: 200,
    loop: true,
    autoplay: {
      delay: 2000
    }
  };

  constructor(private route: ActivatedRoute, private router: Router, public addtoCartservice: AddtocartService)
   {
    this.route.queryParams.subscribe(params => {
      if (params && params.speacial) {
        this.single = JSON.parse(params.speacial);
      }
    });
  }

  ngOnInit() {
  }

  addToCart(member) {
    if (this.addtoCartservice.cart.length === 0) {
      // console.log('array is empty');
      this.addtoCartservice.getCart(member);
      console.log('array is empty', member);
    } else {
      const temp = this.addtoCartservice.cart.filter(element => element.id === member.id);
      console.log('temp', temp);
      if (temp.length === 0) {
        this.addtoCartservice.cart.push(member);
      } else {
        // eslint-disable-next-line @typescript-eslint/prefer-for-of
        for (let p = 0; p < this.addtoCartservice.cart.length; p++) {
          if (member.id === this.addtoCartservice.cart[p].id) {
            console.log('id is add');
            this.addtoCartservice.cart[p].amount += 1;
          }
        }
      }
    }
    this.router.navigate(['cart']);
  }
}

