import { HomePage } from './pages/home/home.page';
import { Component } from '@angular/core';
import { SplashScreen } from '@awesome-cordova-plugins/splash-screen/ngx';
import { StatusBar } from '@awesome-cordova-plugins/status-bar/ngx';
import { Platform, ModalController } from '@ionic/angular';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {

  rootPage: any = HomePage;

  constructor(public splashScreen: SplashScreen, public platform: Platform, public modelCtrl: ModalController,
    private statusBar: StatusBar ) {

      platform.ready().then(async () => {
        statusBar.styleDefault();
      });
    }

}
